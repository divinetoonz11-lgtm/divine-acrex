export default function UserDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>User Dashboard</h1>
      <p>Welcome User! (Demo)</p>
    </div>
  );
}
