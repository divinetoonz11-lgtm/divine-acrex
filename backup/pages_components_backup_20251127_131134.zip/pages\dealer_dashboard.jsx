export default function DealerDashboard() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Dealer Dashboard</h1>
      <p>Welcome Dealer! (Demo)</p>
    </div>
  );
}
