export const LISTING_IMAGES = [
  { id: 1, publicPath: "/images/listing-example-1.png" },
  { id: 2, publicPath: "/images/listing-example-2.png" },
  { id: 3, publicPath: "/images/listing-example-3.png" },
  { id: 4, publicPath: "/images/listing-example-4.png" },
  { id: 5, publicPath: "/images/listing-example-5.png" },
  { id: 6, publicPath: "/images/listing-example-6.png" },
];

export default LISTING_IMAGES;
